package loopsfruity.fruityloops.models;

public class item {
    public String name;
    public double price;
    
    public item(String name, double price){
        this.name=name;
        this.price=price;
    }
}
